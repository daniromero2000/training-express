# Views
- module that does the actual rendering of Views
- express is unnopionated about with view engine you use

- simple-rendering/
- complex-view-rendering/

# render process
- express builts up the context every time you call render
- you decide wheter view is cached enabled
